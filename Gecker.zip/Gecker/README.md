Instagram Viewer
-----

This is a basic instagram realtime RSS reader that queries based on tags. It was done for a friend doing an art exhibit that involves 
near realtime instagram interaction.  
